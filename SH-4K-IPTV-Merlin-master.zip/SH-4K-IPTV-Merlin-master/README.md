# SH-4K-IPTV-Merlin

4K-iptv please run

    cd /jffs/scripts/ && rm -rf SHiptv.sh && wget --no-check-certificate https://raw.githubusercontent.com/PatrikYang/SH-4K-IPTV-Merlin/master/SHiptv.sh && chmod +x SHiptv.sh && sh SHiptv.sh

iptv7x please run

    cd /jffs/scripts/ && rm -rf iptv7x.sh && wget --no-check-certificate https://raw.githubusercontent.com/PatrikYang/SH-4K-IPTV-Merlin/master/iptv7x.sh && chmod +x iptv7x.sh && sh iptv7x.sh
